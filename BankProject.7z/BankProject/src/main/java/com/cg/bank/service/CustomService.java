package com.cg.bank.service;

import com.cg.bank.bean.Customer;
import com.cg.bank.exception.CustomException;

public interface CustomService {
	public boolean addCustomer(Customer cust) throws CustomException;
	   

	   
    public int loginByUsername(String username, String password) throws CustomException;
   
    public double deposit(int accountNo, double amount) throws CustomException;
   
    public double withdraw(int accountNo,double amount) throws CustomException;
   
    public double showBalance(int accountNo) throws CustomException;
   
    public String  fundTransfer(int accountNo1,int accountNo2,double amount) throws CustomException;

	Customer getCustomerDetails(int accountNo) throws CustomException;
}
